AudioMancer Windows x64 v1.3.0

This folder is a portable AudioMancer release.

Start:
- Double-click AudioMancer.exe, or
- Double-click Start-AudioMancer.cmd.

Install:
- Extract the full zip folder before starting the app.
- Keep the files together; the executable depends on bundled runtime files.

Configuration and licenses are included next to the executable.
Prompt templates are included in prompts\.
Offline help is included in help\en\index.html and help\ro\index.html.
