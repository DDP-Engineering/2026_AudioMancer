@echo off
setlocal
cd /d "%~dp0"
"%~dp0AudioMancer.exe" %*
